package ws;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

public class WebService {
	public String url = "http://skin.searshc.com/skinws/Web/";
	public String webServiceCall(String url){
		
		//Creating the HTTP GET request 
		HttpClient httpclient = new DefaultHttpClient();
		HttpGet request = new HttpGet(url);

		//request.addHeader("accept", "application/json");
		

		String response="";
		
		ResponseHandler<String> handler = new BasicResponseHandler();
		try {  
			response = httpclient.execute(request, handler);  
        } catch (ClientProtocolException e) {  
            e.printStackTrace();  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
        httpclient.getConnectionManager().shutdown();
        
        
        return response;
		
		
	}
	
	public String webServicePost(String url, Map<String, String> parameters){
		
		//Creating the HTTP GET request 
		HttpClient httpclient = new DefaultHttpClient();
		HttpPost request = new HttpPost(url);
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(parameters.size());
		for (Map.Entry<String, String> entry : parameters.entrySet()) {
			nameValuePairs.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
		}
        
        try {
			request.setEntity(new UrlEncodedFormEntity(nameValuePairs));
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}

		

		String response="";
		
		ResponseHandler<String> handler = new BasicResponseHandler();
		try {  
			response = httpclient.execute(request, handler);  
        } catch (ClientProtocolException e) {  
            e.printStackTrace();  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
        httpclient.getConnectionManager().shutdown();
        
        
        return response;
		
		
	}
	
}
