package ws;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class getRout extends HttpServlet {
	WebService ws = new WebService();
	private String wsUrl = "http://skin.searshc.com/demo/Norridge/php/getRouteFromCoordinates.php";
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		
		PrintWriter out;
		res.setContentType("text/plain");
	    out = res.getWriter();
		
		try{
			Map<String, String> map = new HashMap<String, String>();
			map.put("storeID", req.getParameter("storeNumber"));
			map.put("source_json", req.getParameter("source"));
			map.put("destination_json", req.getParameter("destination"));
		    String response = ws.webServicePost(wsUrl, map);
		    out.println(response);
		} 
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	  

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doGet(req, res);
	}
}