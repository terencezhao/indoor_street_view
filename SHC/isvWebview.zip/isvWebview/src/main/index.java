package main;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class index
 */
public class index extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String platform = request.getParameter("platform");
		String storeNumber = request.getParameter("storeNumber");
		Init init = new Init();

		if(platform != null){
			init.setPlatform(platform);
		}
		if(storeNumber != null){
			init.setStoreNumber(storeNumber);
		}

		String jsName = init.platform;
		String file;
		if(!init.storeNumber.isEmpty()){
			if(!jsName.isEmpty()){
				jsName += "/";
			}
			jsName += init.storeNumber;
			init.setJs(jsName);
			file = "index.jsp";
		}
		else{
			file = "index.html";
		
		}

		request.setAttribute("init", init);
		
		RequestDispatcher dispather = request.getRequestDispatcher(file);
		dispather.forward(request, response);
	}

}
