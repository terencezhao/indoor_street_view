var panorama;
var polyLine;
var markers = [];
var deals = [];
var isvData = {};
var isvDeals= {};
var coupons = {};
var i=0;
var markerHash = {};
var currentMarker = null;
var floor = 1;


function initialize(callback)
{
	var panoOptions =
  	{
		visible: true,
		disableDoubleClickZoom: false,
 		zoomControl: true,
 		panControl: false,
		zoomControlOptions: {
			style: google.maps.ZoomControlStyle.LARGE, 
			position: google.maps.ControlPosition.LEFT_CENTER
		},
		panoProvider: getCustomPanorama,
  		pov: {
  			heading: 0,
  			pitch: 0,
  			zoom: 0
  		}
  	};		
	panorama = new google.maps.StreetViewPanorama(document.getElementById("pano-canvas"), panoOptions);
	var floorNumber = floor.toString();
	$.get("http://localhost:8080/SKIN20/Web/isv/getPanos?store=1570&floor="+floorNumber, {}, function(panoData){  		
	    if(panoData)
	    {
			for(index in panoData)
			{	
				var obj = panoData[index];
				var entry = obj[0].img;//obj[0].id;	      	        
				isvData[entry] =
				{
					id: obj[0].id,
					pano: obj[0].img,//obj[0].id,
					description: obj[0].desc,
					latLng: new google.maps.LatLng(obj[1].lat, obj[1].lng),
					centerHeading: obj[0].centerHeading,
					links:
					[
						{pano: obj[0].isvLink1, heading: obj[0].heading1},
						{pano: obj[0].isvLink2, heading: obj[0].heading2},
						{pano: obj[0].isvLink3, heading: obj[0].heading3},
						{pano: obj[0].isvLink4, heading: obj[0].heading4},
						{pano: obj[0].isvLink5, heading: obj[0].heading5}
					],
					departmentId: obj[2].id
				};
	  	  	};
	  	  	//alert(JSON.stringify(isvData));
	  		$.get("http://localhost:8080/SKIN20/Web/loc/getEventLocationsByStore?store=1570", {}, function(eventData){
		  		if(eventData)
		  		{
		  			for(index in eventData) 
		  			{
		  				var obj = eventData[index];		
		  				var events = obj.eventLocations;	
		  				for(index in events)
		  				{
		  					var event = events[index];
		  					var deal = 
		  	  				{
		  	  	  				image: event.image, 
		  	  	  				event: event.eventName,
		  	  	  				link: 'http://www.sears.com/'
		  	  	  			};
		  					var deptId = event.deptId;		
			  				if(isvDeals[deptId] == null)
			  				{
			  					isvDeals[deptId] = new Array();
			  				}
		  	  				isvDeals[deptId].push(deal);
		  				}
		  			}
		  		}
	  		});
	  	  	callback();
	    }
	});
}

initialize(function(){
	$('#pov').hide();
	//setUpPanoCanvas();
	control.changeFloor(floor);
	setUpMarkers();
	setUpPolyLine();
	$('#pano-tour').toggle(
		function(){
			panoTour(true);
			$('#pano-tour').text("Stop Tour");
		},
		function(){
			panoTour(false);
			$('#pano-tour').text("Start Tour");
		}
	);
	addCoupons();
	/*
	$('#floorNumber').change(function(){
		var floor = $('#floorNumber').val();
		alert(floor);
		control.changeFloor(floor);
		initialize();
	});
	*/
	if(floor == 1);
	{
		panorama.setPano("AA1");
	}
	if(floor == 2)
	{
		panorama.setPano("N1");
	}
});

/**
 * Adds coupons overlays onto the Street View
 * Should be refactored to allow for dynamic 
 * hiding and showing of coupons based on location
 */
function addCoupons()
{
	var coupon = new google.maps.Marker({
		position: new google.maps.LatLng(42.0448100288894, -88.0351269733642),
		icon: control.get("imgDir")+"dyson.jpg",
		map: panorama,
		title: "Dyson Deal",
		visible: false
	});
	google.maps.event.addListener(panorama, 'pano_changed', function(){
		var key = panorama.getPano();
		if(key == "A4")
		{
			coupon.setVisible(true);
		}
		else
		{
			coupon.setVisible(false);
		}
	});
	google.maps.event.addListener(coupon, 'click', function(){
		var url = "http://www.sears.com/dyson-dc41-animal-bagless-upright-vacuum-cleaner/p-02039541000P?prdNo=1&blockNo=1&blockType=G1";
		window.open(url, '_blank');
		window.focus();
	});
}

/*
function panoTour(flag)
{
	
	if(flag)
	{	
		google.maps.event.trigger(markers[i], 'click');
		if(i < markers.length-1)
		{
			i++;
		}
		else
		{
			i = 0;
		}
		loop = setTimeout(function(){panoTour(true);}, 1500);
	}
	else
	{
		clearTimeout(loop);
	}
}

function setUpPanoCanvas()
{
	google.maps.event.addListener(panorama, 'pov_changed', function(){
		document.getElementById('pov').value = panorama.getPov().heading;
	});
}
*/


/**
 * Adds markers to the skin map
 * Uses the isvData object to set marker options
 * Stores markers in data structure (array and hash)
 * Add a click listener to each marker 
 */
function setUpMarkers()
{
 	for (var key in isvData)
 	{
 		if (isvData.hasOwnProperty(key))
 		{
 			var locId = isvData[key].id;
 			var position = isvData[key].latLng;
 			var icon = "redDot.png";
 			var marker = new google.maps.Marker({
 				title: locId.toString(),
 				icon: control.get("imgDir")+icon,
 				position: position,
 				map: control.map.googleMap,
 				visible: true
 			});
 			markers.push(marker);
 			markerHash[key] = marker;
 			clickListener(marker, key);
 		}
 	}
 	markerHash["A4"].setIcon(control.get("imgDir")+"sale.png");
}


/**
 * On marker click: set the panorama and update current location marker  
 */
function clickListener(marker, key)
{
	google.maps.event.addListener(marker, 'click', function(){
		panorama.setPano(key);
		setCurrentMarker(key);
	});	
}

/**
 * Changes the current location marker icon
 * Also hides deals display if there are none in the department
 */
function setCurrentMarker(key)
{
	var marker = markerHash[key];
	if(currentMarker != null)
	{
		currentMarker.setIcon(control.get("imgDir")+"redDot.png");
	}
	marker.setIcon(control.get("imgDir")+"me.png");
	currentMarker = marker;
	var deptId = isvData[key].departmentId;
	$("#deals").empty();
	if(isvDeals[deptId]==null)
	{
		$('#dealsCarousel').hide();
	}
	else
	{
		$('#dealsCarousel').slideDown();
		$.each(isvDeals[deptId], function(key, value){
			//alert(value.event);
			$("#deals").append('<li><a href='+value.link+' title='+value.event+'><img class="enlarge-onhover" src='+value.image+' height="90" width="90" alt="Deal1" /></a></li>');
		});
		$('.infiniteCarousel').infiniteCarousel();
		//$("ul").listview("refresh");
	}
}

/**
 * Draws paths between each connected location
 */
function setUpPolyLine()
{
	for (var key in isvData)
	{
		if(isvData.hasOwnProperty(key))
		{
			var current = isvData[key];
			var start = current.latLng;
			for (index in current.links)
			{
				var linkID = current.links[index].pano;
				if(typeof linkID != 'undefined')
				{
					var end = isvData[linkID].latLng;
					var path = new Array();
					path.push(start, end);
					control.addPolyLine("green", 0.5, 10, path);
				}
			}
		}
	}
}

/**
 * Crafts urls to return images from server
 * @param {String} pano 
 * @param {Number} zoom
 * @param {Number} tileX
 * @param {Number} tileY
 * @return {String} url
 */
function getCustomPanoramaTileUrl(pano,zoom,tileX,tileY) 
{
	var url = 'http://skin-dev.searshc.com/Skin20ISV/1570/'+pano+'-tiles'+'/'+pano+'_'+zoom+'_'+tileX+'_'+tileY+'.jpg';
	return url;
}

/**
 * Centers map on current location and set marker
 * Returns a custom panorama with location information, links, and tiled images
 */
function getCustomPanorama(pano)
{
	var customPano = isvData[pano];
	control.panTo(customPano.latLng);
 	setCurrentMarker(pano);
 	var links = getCustomLinks(pano);
 	return {
		location:
		{
			pano: customPano.pano.toString(),//customPano.image.toString(),
			description: customPano.description.toString(),
			latLng: customPano.latLng
		},
		links: links,
		copyright: "(c) 2012 SHC",
		tiles:
		{
			tileSize: new google.maps.Size(256, 256),
			worldSize: new google.maps.Size(16348, 8192),
			centerHeading: customPano.centerHeading,
			getTileUrl: getCustomPanoramaTileUrl
		}
	};
}

/**
 * Adds links to current panorama
 * Sets link labels based on the description field of their destinations 
 */
function getCustomLinks(pano)
{
 	var links = new Array();
 	var customPano = isvData[pano];
 	for (index in customPano.links)
	{
		var linkID = customPano.links[index].pano;
		if(typeof linkID != 'undefined')
		{
			links.push({
				heading: customPano.links[index].heading,
				description: isvData[linkID].description.toString(),
				pano: isvData[linkID].pano.toString()
			});
		}
	}	
 	return links;
}
