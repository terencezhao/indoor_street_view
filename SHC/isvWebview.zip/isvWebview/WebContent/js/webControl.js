// web control
$(document).keyup(function(event){
    if(event.which == 49){
        //control.changeFloor(1);
        skinMap.setMapType("ROADMAP");    
    }
    else if(event.which == 50){
        control.changeFloor(2);
    }
    else if(event.which == 51){
        //control.routMe();
        skinMap.setMapType("none");
    }
    else if(event.which == 52){
        control.showMe(41.9568, -87.804, true);
    }
    else if(event.which == 53){
        control.routMe();
        //control.showDept(41);
    }
    else if(event.which == 54){
        //control.showPoi(23);
        control.hideImportantPoi();
    }
    else if(event.which == 55){
        control.showPoi(24);
    }
    else if(event.which == 56){
        control.getTextNavigation("", "json", function(o){ alert(o); });
    }
    else if(event.which == 57){
        //control.showDept(40);
        control.setAutoRout(false);
    }
    else if(event.which == 82){
        degreeParameter += 15;
        degreeParameter %= 360;
        control.rotate(degreeParameter);
    }
    else if(event.which == 76){
        degreeParameter -= 15;
        degreeParameter %= 360;
        control.rotate(degreeParameter);
    }
    else if(event.which == 69){
        label.set("visible", false);
    }
    else if(event.which == 80){
        skinMap.zoomIn();
    }
    else if(event.which == 77){
        skinMap.zoomOut();
    }
    

});
var degreeParameter = 0;


