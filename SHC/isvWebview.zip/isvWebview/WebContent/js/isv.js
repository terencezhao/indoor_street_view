var skin = (function($, google, skin){
	prototype = skin.map.webview.prototype;
	
	/*
	prototype.changeFloor = function(floorNumber)
	{
		alert("change floor to "+floorNumber);
		control.changeFloor(floorNumber);
	};
	*/
	
	prototype.addMarker = function(title, position, icon)
	{
		//alert("addMarker");
		var myMarker = new skin.map.marker({
			title: title,
            icon: this.get("imgDir")+icon,//"me.png",
            //position: new google.maps.LatLng(lat, lng),
            position: position,
            map: this.map.googleMap,
            dragCrossIcon: this.dragCrossIcon,
            clickable: true,
            draggable: false,
            visible: true,
            animation: false,
            zIndex: 999,
            rotateAnimTime: this.get("rotateAnimTime")
        });	
		return myMarker;		
	};
	
	prototype.addGoogleMarker = function(title, position, icon)
	{
		var marker = new google.maps.Marker({
			title: title,
			icon: this.get("imgDir")+icon,
			position: position,
			map: this.map.googleMap,
			visible: true
		});
		return marker;
	};
	
	prototype.addPolyLine = function(strColor, strOpacity, strWeight, path){
		//alert("Polyline");		
		this.polyLine = new google.maps.Polyline({
			map: this.map.googleMap,
			strokeColor: strColor,
			strokeOpacity: strOpacity,
			strokeWeight: strWeight,
			path: path,
			visible: true
		});
	};
	
	prototype.setStreetView = function(panorama){
		this.map.googleMap.setStreetView(panorama);
	};
	
	/*
	prototype.streetViewControl = function(panorama){
		this.map.googleMap.setStreetView(panorama);
	};
	*/
	
	prototype.panTo = function(Pos){
		this.map.googleMap.panTo(Pos);		
	};
	
	prototype.setLatLngListener = function(){
		//alert("setlatlnglistener");
		google.maps.event.addListener(this.map.googleMap, "click", function(event) {
			//alert("Clicked!");
			//alert(event.latLng.lat()+ " " + event.latLng.lng());	

			document.getElementById('latlongclicked').value = event.latLng.lat() + " " + event.latLng.lng();
			
			alert("isvData is " + isvData);
		 	
			for (var idx in isvData){
				alert("Retrieved data " + isvData[idx].id);
			};
		});
	};	
	
	return skin;
})(jQuery, google, skin || {});
