var skin = (function($, google, skin){
    function getWalkingTime(dist){
        var str = "", WALKINGSPEED_FPS = 4.4, totalSeconds = dist/WALKINGSPEED_FPS, minutes = Math.floor(totalSeconds/60), seconds = Math.round(totalSeconds - minutes*60);

        if(minutes){
            str += minutes + " mins ";
        }
        str += seconds + " secs";
        return str;
    }
    
    function getOrientation(src, dest){
        var degree = google.maps.geometry.spherical.computeHeading(src, dest)+22.5;
        if(degree < 0) degree += 360;
        return Math.floor(degree/45);
    }
    
    function turnDegree(src, dest){
        var degree = (src-dest)*45;
        if(degree <= -180) degree +=360;
        else if(degree > 180) degree -= 360;
        return degree;
    }
    
    function getDirections(locations, navi){
        if(locations.length > 0){
            var oldOrient = -1, size = locations.length, METER2FEET = 3.2808399, current, next, orient, dist = 0;
            for(var i=0; i<size-1; i++){
                current = locations[i].latlng;
                next = locations[i+1].latlng;
                orient = getOrientation(current, next);
                if(oldOrient == -1) oldOrient = orient;
                
                if(orient != oldOrient){
                    navi.add(oldOrient, dist, locations[i].dept, turnDegree(oldOrient, orient));
                    dist = 0;
                    oldOrient = orient;
                }
                dist += Math.round(METER2FEET*google.maps.geometry.spherical.computeDistanceBetween(current, next));
            }
            navi.add(orient, dist, locations[i].dept);
            
        }
        
    }
    
    function styleNavigation(dom){
        $(dom).find("ol, li, p").css({
        "margin": "0",
        "padding": "0"
        });
        $(dom).find("h2").css("text-align", "center");
        $(dom).find("li").css("list-style-type", "none");
        $(dom).find("li + li").css("border-top", "1px solid #333");
        $(dom).find("span.distance").css("color", "#0000FF");
        $(dom).find("span.time").css("color", "#FF0000");
        
    }
    
    function navigation(){
        var turns = {
            "0": "continue",
            "45": "slightly turn right",
            "90": "turn right",
            "135": "turn right",
            "180": "turn back",
            "-45": "slightly turn left",
            "-90": "turn left",
            "-135": "turn left"
        }, directionTerms = ["north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"];
        
        this.totalDist = 0;
        this.directions = [];
        this.from = {img: "", name: ""};
        this.to = {img: "", name: ""};
        
        this.direction = function(head, dist, dept, turn){
            this.dist = dist || 0;
            this.dept = dept || "";
            this.getHead = function(){
                return skin.isSet(head)?directionTerms[head]:"";
            };
            
            this.getTurn = function(){
                return skin.isSet(turn)?turns[turn]:"arrive";
            };
        };
        
        this.add = function(head, dist, dept, turn){
            this.totalDist += dist;
            this.directions.push(new this.direction(head, dist, dept, turn));
        };
        
        this.getLength = function(){
            return this.directions.length;
        };
        
        this.get = function(ind){
            return this.directions[ind];
        };
        
        this.getWalkingTime = function(){
            return getWalkingTime(this.totalDist);
        };
        
        this.clear = function(){
            this.directions = [];
            this.totalDist = 0;
            this.from.img = this.from.name = this.to.img = this.to.name = "";
        };
        
        this.toJson = naviToJson;
        this.toHtml = naviToHtml;
        
    }
    
    function naviToJson(){
        var steps = this.getLength(), direction, json = {}, i;
        if(steps){
            json.totalDist = this.totalDist;
            json.totalTime = this.getWalkingTime();
            json.from = this.from;
            json.to = this.to;
            json.directions = [];

            for(i=0; i<steps; i++){
                json.directions[i] = {};
                direction = this.get(i);
                json.directions[i].turn = direction.getTurn();
                json.directions[i].img = getTurnIcon(json.directions[i].turn);
                json.directions[i].head = direction.getHead();
                json.directions[i].dist = direction.dist;
                json.directions[i].dept = direction.dept;
            }
        }

        return JSON.stringify(json);
    }
    
    function naviToHtml(folder){
        var steps = this.getLength(), direction, div = document.createElement("div"), ol = document.createElement("ol"), li, img, str, turn, i;
        if(steps){
            $(div).append('<h2>Navigation</h2>');
            $(div).append('<p>Distance to destination: <span class="distance">'+this.totalDist+' feet</span>.</p>');
            $(div).append('<p>Estimated walking time: <span class="time">'+this.getWalkingTime()+'</span></p>');
            img = '<img src="'+folder+this.from.img+'" />';
            $(div).append('<p>'+img+'From '+this.from.name+'</p>');
            div.appendChild(ol);

            for(i=0; i<steps; i++){
                direction = this.get(i);
                turn = direction.getTurn();
                img = '<img src="'+folder+getTurnIcon(turn)+'" />';
                str = (i+1)+'. Head '+direction.getHead()+' for <span class="distance">'+direction.dist+' feet</span> then '+turn+' at '+((turn != "arrive")?'department  '+direction.dept:'destination')+'.';
                li = '<li>'+img+str+'</li>';
                $(ol).append(li);
            }
            img = '<img src="'+folder+this.to.img+'" />';
            $(div).append('<p>'+img+'To '+this.to.name+'</p>');
            
            styleNavigation(div);
        }
        
        return div;

    }
    
    function getTurnIcon(turn){
        var turnImage;
        switch (turn) {
            case "turn left":
                turnImage = "left";
                break;
            case "turn right":
                turnImage = "right";
                break;
            case "slightly turn left":
                turnImage = "left";
                break;
            case "slightly turn right":
                turnImage = "right";
                break;        
            case "turn back":
                turnImage = "back";
                break;
            default:
            turnImage = "continue";
        }
        
        return "icon_"+turnImage+".png";
    
    }
    
    function location(lat, lng, dept){
        this.lat = function(){ return lat; }
        this.lng = function(){ return lng; }
        this.latlng = new google.maps.LatLng(lat, lng);
        this.dept = dept || "";
    }
    
    skin.map.webview = function(skinMap, settings, ws){
        var webview = this;
        this.degree = 0;
        this.totalDegree = 0;
        this.lastClick = false;
        
        if(!settings) settings = {};
        if(!ws) ws = {};
        this.map = skinMap;
        
        if(!skin.isSet(settings["imgDir"])){
            settings["imgDir"] = "";
        }
        if(!skin.isSet(settings["storeNumber"])){
            settings["storeNumber"] = "";
        }
        if(!skin.isSet(settings["autoRout"])){
            settings["autoRout"] = true;
        }
        if(!skin.isSet(settings["rotateAnimTime"])){
            settings["rotateAnimTime"] = 0.5;
        }
        
        this.destinations = [];
        this.locations = {};
        this.textNavigation = new navigation();
        this.dragCrossIcon = settings["imgDir"]+"drag_cross.png";
        
        this.getWs = function(wsName){
            if(ws[wsName]) return ws[wsName];
            else return "";
        };
        
        this.get = function(setting){
            return settings[setting];
        };
        
        this.setAutoRout = function(value){
            if(!value && settings["autoRout"]) this.destinations = [];
            settings["autoRout"] = value;
        };
        
        this.myMarker = new skin.map.marker({
            icon: this.get("imgDir")+"me.png",
            position: new google.maps.LatLng(this.map.center[0], this.map.center[1]),
            map: this.map.googleMap,
            dragCrossIcon: this.dragCrossIcon,
            clickable: true,
            draggable: false,
            visible: false,
            animation: true,
            zIndex: 999,
            rotateAnimTime: this.get("rotateAnimTime")
        });

        if(settings["rotateAnimTime"]){
            skin.map.rotateAnimation(document.getElementById(this.map.domId), settings["rotateAnimTime"]);
            
        }
        
        google.maps.event.addListener(this.myMarker, "dragend", function(){
            var container = webview.map.getContainer("rout"), newPosition = webview.getClosestLocation(webview.myMarker.getPosition());
            webview.myMarker.setLocation(newPosition);
            webview.myMarker.setPosition(newPosition);
            if(container.length){
                webview.routMe();
            }
            
        });
        
    };

    skin.map.webview.prototype = {
    	getAllLocations: function(floorName){
            if(!skin.isSet(this.locations[floorName])){
                this.locations[floorName] = [];
                var container = this.locations[floorName], url = this.getWs("getAllLocations");
                if(url){
                    $.get(url, {storeNumber: this.get("storeNumber"), floor: floorName}, function(data){
                        if(data){
                            var locations = JSON.parse(data);
                            $.each(locations, function(ind, ele){
                                container.push(new location(ele.lat, ele.lng, ele.dept));
                            });
                        }
                    });  
                }
            } 
        
        },
        
        getClosestLocation: function(latlng){
            var floorName = this.map.currentFloor, container = this.locations[floorName], minDist = 10000, loc;
            if(container.length){
                $.each(container, function(ind, ele){
                    var distance = google.maps.geometry.spherical.computeDistanceBetween(latlng, ele.latlng);
                    if(distance < minDist){
                        minDist = distance;
                        loc = ele;
                    }
                });
                return loc;
            }
            else{
                return new location(latlng.lat(), latlng.lng());
            }
        
        },
        
        showMe: function(lat, lng, check){
            var marker = this.myMarker, loc;
            if(skin.isSet(lng)){
                marker.setDraggable(false);
                loc = check?this.getClosestLocation(new google.maps.LatLng(lat, lng)):new location(lat, lng);
                marker.setLocation(loc);
                marker.setPosition(loc);
            }
            else{
                marker.setDraggable(true);
                marker.setLocation(this.getClosestLocation(marker.getPosition()));
            }
            
            if(!marker.getVisible()){
                marker.setVisible(true);
            }
        },
        
        hideMe: function(){
            if(this.myMarker.getVisible()){
                this.myMarker.setVisible(false);
                this.removeRout();
            }
        },
        
        changeFloor: function(floorName){
            this.map.clearProperties();
            this.map.putFloor(floorName);
            this.map.showProperties();
            this.getAllLocations(floorName);
        },
        
        register: function(floor){
            this.map.registerProperty(floor, "importantPoi", 11, "fix");
            this.map.registerProperty(floor, "deptPolygon", 9, "fix");
            this.map.registerProperty(floor, "deptLabel", 9, "fix");
            this.map.registerProperty(floor, "poi", 7, "hide");
            this.map.registerProperty(floor, "deal", 7, "remove");
            this.map.registerProperty(floor, "product", 7, "remove");
            this.map.registerProperty(floor, "rout", 3, "remove");
        },
        
        addDept: function(floor, id, name, center, color, paths){
            if(this.map.floors[floor]){
                var map = this.map, visible = (skin.isSet(map.currentFloor) && floor == map.currentFloor)?true:false, deptLabel = map.getContainer("deptLabel", id, floor), deptPolygon = map.getContainer("deptPolygon", id, floor);
                if(name && $.isArray(center)){
                    deptLabel.push(
                        new skin.map.label({
                            map: map.googleMap,
                            text: name,
                            rotateAnimTime: this.get("rotateAnimTime"),
                            position: new google.maps.LatLng(center[0], center[1]),
                            visible: visible,
                            minZoom: 19,
                            css: {
                                "font-family": "Arial",
                                "font-size": "10px",
                                "font-weight": "bold",
                                "text-shadow": "0.1em 0.1em #FFF"
                            },
                            sizeEq: function(zoom){
                                return (10+(zoom-19)*6)+"px";
                            }
                        })
                    );
                }
                
                if(paths){
                    var deptPaths = [];
                    
                    $.each(paths, function(pathInd, path){
                        deptPaths[pathInd] = [];
                        $.each(path, function(ind, ele){
                            deptPaths[pathInd].push(new google.maps.LatLng(ele[0], ele[1]));
                        });
                    });
                    
                    deptPolygon.push( 
                        new google.maps.Polygon({
                            strokeWeight: 1,
                            strokeColor: color,
                            strokeOpacity: 0.8,
                            fillOpacity: 0.55,
                            fillColor: color,
                            map: this.map.googleMap,
                            visible: visible,
                            paths: deptPaths
                        })
                    );
                }
            }
        },
        
        showDept: function(id){
            if(skin.isSet(id)){
                var map = this.map, deptLabel = map.getContainer("deptLabel", id), deptPolygon = map.getContainer("deptPolygon", id), weight = map.getWeight("deptLabel");
                map.showProperties(weight);
                map.clearProperties(weight);
                if(deptLabel.length){
                    $.each(deptLabel, function(ind, ele){
                        ele.setVisible(true);
                    });
                    map.googleMap.setZoom(19);
                    map.googleMap.setCenter(deptLabel[0].getPosition());
                }
                if(deptPolygon.length){
                    $.each(deptPolygon, function(ind, ele){
                        ele.setVisible(true);
                    });
                }
                
            }
            else{
                this.map.showProperties();
            }
        },
        
        hideDept: function(){
            this.map.clearProperty("deptLabel");
            this.map.clearProperty("deptPolygon");
        },
        
        addImportantPoi: function(floor, id, name, position){
            if(this.map.floors[floor]){
                var map = this.map, visible = (skin.isSet(map.currentFloor) && floor == map.currentFloor)?true:false, importantPoi = map.getContainer("importantPoi", id, floor);
                if(name && $.isArray(position)){
                    importantPoi.push(
                        new skin.map.label({
                            map: map.googleMap,
                            text: name,
                            rotateAnimTime: this.get("rotateAnimTime"),
                            position: new google.maps.LatLng(position[0], position[1]),
                            visible: visible,
                            css: {
                                "font-family": "Arial",
                                "font-size": "10px",
                                "font-weight": "bold",
                                "text-shadow": "0.1em 0.1em #FFF"
                            },
                            sizeEq: function(zoom){
                                return ((zoom>19)?(10+(zoom-19)*6):10)+"px";
                            }
                        })
                    );
                }
                
            }
        },
        
        showPoi: function(id){
            if(skin.isSet(id)){
                var map = this.map;
                if(!map.isSetContainer("poi", id)){
                    var url = this.getWs("poiLocations"), img = id+".png", webview = this;
                    if(url){
                        $.get(url, {storeNumber: this.get("storeNumber"), floorName: map.currentFloor, poiId: id}, function(data){
                            map.clearProperties(map.getWeight("poi"));
                            map.showProperties();
                            
                            if(data){
                                var locations = JSON.parse(data), container = map.getContainer("poi", id);
                                locations.sort(skin.compare("longitude"));
                                $.each(locations, function(ind, ele){
                                    var marker = new skin.map.marker({
                                        position: new google.maps.LatLng(ele.latitude, ele.longitude),
                                        map: map.googleMap,
                                        icon: webview.get("imgDir")+img,
                                        imgName: img,
                                        name: ele.poi_name,
                                        clickable: true,
                                        visible: true,
                                        zIndex: 99,
                                        degree: -1*webview.totalDegree,
                                        animation: true,
                                        rotateAnimTime: webview.get("rotateAnimTime")
                                    });
                                  
                                    
                                    google.maps.event.addListener(marker, "click", function(){
                                        var loc = marker.getLocation();
                                        webview.lastClick = this;
                                        if(!loc){    
                                            loc = webview.getClosestLocation(marker.getPosition());
                                            marker.setLocation(loc);
                                        }
                                        if(webview.get("autoRout")){
                                            webview.destinations = [];
                                            webview.destinations[0] = loc;
                                            webview.routMe();
                                        }
                                        else{
                                            webview.destinations.push(loc);
                                        }
                                        
                                    });
                                    
                                    container.push(marker);
                                });
                            }
                        });
                    }
                }
                else{
                    map.clearProperties(map.getWeight("poi"));
                    map.showProperties();
                    $.each(map.getContainer("poi", id), function(ind, ele){
                        ele.setVisible(true);
                    });
                }
            }
        
        },
        
        hidePoi: function(){
            this.map.clearProperty("poi");
        },
        
        getRout: function(routs, callback, index){
            if(!skin.isSet(index)) index = 0;
            if(index < routs.length){
                var webview = this, map = this.map, srcJson = '{"latitude":"'+routs[index][0].lat()+'","longitude":"'+routs[index][0].lng()+'"}', destJson = '{"latitude":"'+routs[index][1].lat()+'","longitude":"'+routs[index][1].lng()+'"}', url = this.getWs("getRout");
                if(url){
                    $.post(url, {storeNumber: this.get("storeNumber"), floorName: map.currentFloor, source: srcJson, destination: destJson}, function(data){
                        if(index == 0){
                            map.clearProperties(webview.map.getWeight("rout"));
                            map.showProperties();
                        }
                        
                        if(data){
                            var nodes = JSON.parse(data), container = map.getContainer("rout"), path = [], pathLocations = [];
                        
                            $.each(nodes, function(ind, ele){
                                path.push(new google.maps.LatLng(ele.latitude, ele.longitude));
                                pathLocations.push(new location(ele.latitude, ele.longitude, ele.department));
                            });
                            container.push( 
                                new google.maps.Polyline({
                                    strokeColor: "#241FB1",
                                    strokeOpacity: 0.7,
                                    strokeWeight: 7,
                                    map: map.googleMap,
                                    path: path
                                })
                            );
                        
                            if(skin.isFunction(callback)){
                                callback(index, pathLocations);
                            }
                            
                            webview.getRout(routs, callback, ++index);
                        }
                    });
                }
            }
            
        },
        
        routMe: function(){
            if(this.destinations.length){
                if(this.myMarker.getVisible()){
                    var navi = this.textNavigation, source = this.myMarker.getLocation(), routs = [];

                    navi.clear();
                    navi.from.img = "me.png";
                    navi.to.img = this.lastClick.get("imgName");
                    navi.to.name = this.lastClick.get("name");
                    $.each(this.destinations, function(ind, ele){
                        routs.push([source, ele]);
                        source = ele;
                    });
                    
                    this.getRout(routs, function(index, locations){
                        if(index == 0) navi.from.name = "department "+locations[0].dept; 
                        getDirections(locations, navi);
                    });
                }
            }
        },
        
        removeRout: function(){
            this.map.clearProperty("rout");
        },
        
        getTextNavigation: function(folder, type, handler){
            var o;
            folder = (folder !== false)?folder:this.get("imgDir");
            type = type || "html";
            
            switch (type) {
                case "html":
                    o = $(this.textNavigation.toHtml(folder)).html();
                    break;
                case "dom":
                    o = this.textNavigation.toHtml(folder);
                    break;
                case "json":
                    o = this.textNavigation.toJson();
                    break;
            
            }
            
            if(skin.isFunction(handler)){
                handler(o);
            }
            else{
                return o;
            }
        },
        
        rotate: function(degree, skipMap){
            var interval = degree - this.degree;
            if(interval != 0){
                if(this.totalDegree != 0){
                    if(interval > 180) interval -= 360;
                    else if(interval < -180) interval += 360;
                }
                this.degree = degree;
                this.totalDegree += interval;

                if(!skipMap){
                    skin.map.doRotation("#"+this.map.domId, this.totalDegree);
                }
                skin.map.doRotation(".skin-marker, .skin-label", -1*this.totalDegree);
            }
        
        }


    };
    
    return skin;


})(jQuery, google, skin || {});
