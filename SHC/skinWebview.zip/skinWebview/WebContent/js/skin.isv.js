var skin = (function($, google, skin)
{
	prototype = skin.map.webview.prototype;
	var path = [];
	var nodes = {};
	var links = {};
	var nodeHasPano = {};
	var latLngA = null;
	var latLngB = null;
	var panoA = null;
	var panoB = null;
	//var pathHash = {};
	
	// Place markers on all available locations
	prototype.getLocations = function(floorName)
	{
		if(skin.isSet(this.locations[floorName]))
		{
            this.locations[floorName] = [];
            var container = this.locations[floorName], url = this.getWs("getAllLocations");
            if(url)
            {
                $.get(url, {storeNumber: this.get("storeNumber"), floor: floorName}, function(data){
                    if(data)
                    {
                        var locations = JSON.parse(data);
                        for (index in locations)
                        {  
                        	var id = locations[index].id;
                            var pos = new google.maps.LatLng(locations[index].lat, locations[index].lng);
                        	if(id >= 37945)
                        	{
                            	control.addMarker(pos, id);
                        	}
                        }
                        $.each(locations, function(ind, ele){
                        	container.push(new location(ele.lat, ele.lng, ele.dept));
                        });
                    }
                });  
            }
        } 
    };
    
    // Draws initial markers on the map
	prototype.addMarker = function(pos, id)
	{
		var marker = new skin.map.marker({
			title: id,
            icon: this.get("imgDir")+"redDot.png",//this.get("imgDir")+"me.png",
            position: pos,
            map: this.map.googleMap,
            dragCrossIcon: this.dragCrossIcon,
            clickable: true,
            draggable: false,
            visible: true,
            animation: false,//true,
            zIndex: 999,
            rotateAnimTime: this.get("rotateAnimTime")
        });	
		google.maps.event.addListener(marker, "click", function(){
			var pano = id;//env.storeNumber+"-"+id;
			links[pano] = [];
			control.addNode(pos, "me.png", pano); 
		});
	};
	
	// Adds a click-able node to the map. click on node to access pano upload and link setup
	prototype.addNode = function(pos, icon, pano)
	{
		var node = new skin.map.marker({
	        title: pano,
			icon: this.get("imgDir")+icon,
	        position: pos,
	        map: this.map.googleMap,
	        dragCrossIcon: this.dragCrossIcon,
	        clickable: true,
	        draggable: false,
	        visible: true,
	        animation: true,
	        zIndex: 999,
	        rotateAnimTime: this.get("rotateAnimTime")
        });	
		nodes[pano] = node;
		nodeHasPano[pano] = false;
		google.maps.event.addListener(node, "click", function(){
			if(nodeHasPano[pano])
			{
				$('#link-start').button('enable');
				control.listenLinkStart(pano, pos);
				$('#link-end').button('enable');
				control.listenLinkEnd(pano, pos);
				$('#delete-node').button('enable');
				control.listenDeleteNode(pano);
				$('#upload-pano').button('disable');
			}
			else
			{
				$('#upload-pano').button('enable');
				control.listenUploadPano(pano, pos);
				$('#delete-node').button('enable');
				control.listenDeleteNode(pano);
			}
		});
	};
	
	
	// Upload panorama image to the server and show preview
	prototype.listenUploadPano = function(pano, pos)
	{
		$('#upload-pano').click(function(){
//WEBSERVICE: Set current position's panoId to pano
			control.setStreetView(pano);
			nodeHasPano[pano] = true;
			$('#link-start').button('enable');
			control.listenLinkStart(pano, pos);
			$('#link-end').button('enable');
			control.listenLinkEnd(pano, pos);
			$('#street-view').slideDown();
		});
	};
	
	// Deletes a node marker on the map
	prototype.listenDeleteNode = function(pano)
	{
		$('#delete-node').click(function(){
			var delNode = nodes[pano];
			delNode.setMap(null);
			$('#link-start').button('disable');
			$('#link-end').button('disable');
			$('#delete-node').button('disable');
			$('#upload-pano').button('disable');
		});
	};
	
	// Link Start button click listener
	prototype.listenLinkStart = function(pano, pos)
	{
		$('#link-start').click(function(){
			$('#street-view').slideUp();
			$('#linkA').val(pano);
			$('#posA').val(pos);
			latLngA = pos;
			panoA = pano;
			//pathHash[panoA] = {};
			$('#link-start').button('disable');
			$('#link-end').button('disable');
			$('#upload-pano').button('disable');
			$('#delete-node').button('disable');
			control.linkReady(pano, pos);
		});
	};
	
	// Link End button click listener
	prototype.listenLinkEnd = function(pano, pos)
	{
		$('#link-end').click(function(){
			$('#street-view').slideUp();
			$('#linkB').val(pano);
			$('#posB').val(pos);
			latLngB = pos;
			panoB = pano;
			//pathHash[panoB] = {};
			$('#link-start').button('disable');
			$('#link-end').button('disable');
			$('#upload-pano').button('disable');
			$('#delete-node').button('disable');
			control.linkReady(pano);
		});	
	};
	
	// Checks if both link start and end are filled, then adds path
	// Sets up listener on paths to remove them
	prototype.linkReady = function(pano)
	{
		if(($('#linkA').val().length > 0)&&($('#linkB').val().length > 0))
		{
			$('#add-link').button('enable');
			$('#add-link').click(function(){
				if(($('#linkA').val().length > 0)&&($('#linkB').val().length > 0))
				{
					path.length = 0;
					path.push(latLngA, latLngB);			
					var line = control.addPolyLine("green", 0.5, 10, path);
					//pathHash[panoA][panoB] = line;
					//pathHash[panoB][panoA] = line;
//WEBSERVICE: Add a link from A to B and B to A
					$('#add-link').button('disable');
					$('#remove-link').button('disable');
					$('#linkA').val("");
					$('#linkB').val("");
					$('#posA').val("");
					$('#posB').val("");
					google.maps.event.addListener(line, "click", function(){
						$('#remove-link').button('enable');
						$('#remove-link').click(function(){
							line.setMap(null);
							$('#remove-link').button('disable');
//WEBSERVICE: Remove link from A to B and B to A)
//A = line.getPath().getAt(0);
//B = line.getPath().getAt(1);
						});
					});
				}
			});
		}	
	};

	// Draws polyline path on map
	prototype.addPolyLine = function(strColor, strOpacity, strWeight, path)
	{
		var polyLine = new google.maps.Polyline({
			map: this.map.googleMap,
			strokeColor: strColor,
			strokeOpacity: strOpacity,
			strokeWeight: strWeight,
			path: path,
			visible: true	
		});	
		return polyLine;
	};
	
	// Sets the street view panorama
	prototype.setStreetView = function(pano){
		alert("setStreetView with "+pano);
		panorama.setPano(pano);
	};
	
	
	prototype.panTo = function(Pos){
		this.map.googleMap.panTo(Pos);		
	};
	
		
	return skin;
})(jQuery, google, skin || {});
