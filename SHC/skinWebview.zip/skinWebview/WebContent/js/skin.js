var skin = (function(){
    return {
        debug: false,
        error: 0,
        
        alertError: function(str){
            skin.error++;
            if(skin.debug){
                alert("Error: "+str+"!");
            }
        },
    
        isString: function(o){
            return typeof(o) == "string";
        },
    
        isSet: function(o){
            return typeof(o) != "undefined";
        },
    
        isFunction: function(o){
            return typeof(o) == "function";
        },
        
        compare: function(p){
            return function(a,b){
                return (a[p] < b[p])?-1:(a[p] > b[p])?1:0;
            }
        }

    };
    
})();

var skin = (function($, google, skin){
    function createGoogleMap(domId, center, settings){
        var googleMapOpt = {
            center: new google.maps.LatLng(center[0], center[1]),
            zoomControl: settings.zoomControl,
            zoomControlOptions: {
                style: google.maps.ZoomControlStyle.SMALL,
                position: google.maps.ControlPosition.LEFT_CENTER
            },
            zoom: settings.initZoom,
            minZoom: settings.minZoom,
            maxZoom: settings.maxZoom,
            panControl: settings.panControl,
            streetViewControl: false,
            mapTypeControl: false,
            mapTypeId: settings.mapType,
            backgroundColor: settings.backgroundColor
        };
        
        $("#"+domId).css({
            "width": settings.width,
            "height": settings.height
        });

        return new google.maps.Map(document.getElementById(domId), googleMapOpt);
    }
    
    function backgroundMapType(img, color, size){
        img = img || false;
        color = color || false;
        size = size || 256;
        this.tileSize = new google.maps.Size(size, size);
        this.maxZoom = 21;
        this.getTile = function(coord, zoom, ownerDocument){
            var dom = ownerDocument.createElement("div");
            dom.className = "skin-background";
            dom.style.width = this.tileSize.width + "px";
            dom.style.height = this.tileSize.height + "px";
            if(color){
                dom.style.backgroundColor = color;
            }
            if(img){
                dom.style.backgroundImage="url('"+img+"')";
             }
            return dom;
        };
    }
    
    skin.map = function(domId, center, initOpt){
        if(!domId) skin.alertError("No DOM ID");
        else this.domId = domId;
        if(!center) skin.alertError("No center location");
        else this.center = center;
        
        if(!initOpt) initOpt = {};
        initOpt.width = initOpt.width || "100%";
        initOpt.height = initOpt.height || "100%";
        
        initOpt.minZoom = initOpt.minZoom || 17;
        initOpt.maxZoom = initOpt.maxZoom || 21;
        initOpt.initZoom = (initOpt.initZoom && initOpt.initZoom >= initOpt.minZoom && initOpt.initZoom <= initOpt.maxZoom)?initOpt.initZoom:initOpt.minZoom;
        initOpt.zoomControl = initOpt.zoomControl || false;
        initOpt.panControl = initOpt.panControl || false;
        initOpt.backgroundColor = initOpt.backgroundColor || "#000";
        
        var background = {};
        background["none"] = new backgroundMapType();
        background["transition"] = new backgroundMapType(false, initOpt.backgroundColor);
        if(initOpt.backgroundImage){
            background["image"] = new backgroundMapType(initOpt.backgroundImage);
            initOpt.mapType = "image";
        }
        else{
            background["image"] = background["none"];
            initOpt.mapType = "none";
        }
        
        this.floors = {};

        if(!skin.error){
            this.googleMap = createGoogleMap(this.domId, this.center, initOpt);
            this.googleMap.mapTypes.set("none", background["none"]);
            this.googleMap.mapTypes.set("transition", background["transition"]);
            this.googleMap.mapTypes.set("image", background["image"]);
        }
        
        this.getOption = function(opt){
            return initOpt[opt];
        };
        
        this.setMapType =function(mapName){
            var map = this.googleMap, selector = "#"+this.domId;
            map.setMapTypeId("transition");
            $(selector).delay(200).queue(function(next){
                if(mapName != "none" && mapName != "image"){
                    $(selector).css("background-color", "#E5E3DF");
                    mapName = google.maps.MapTypeId[mapName];
                }
                else{
                    $(selector).css("background-color", initOpt.backgroundColor);
                 }
                map.setMapTypeId(mapName);
                next();
            });
        };
    };
    
    skin.map.dropAnimation = function(dom, height){
        $(dom).css({
            "top": "-"+height+"px",
            "transition": "top 0.25s linear",
            "-moz-transition": "top 0.25s linear",
            "-webkit-transition": "top 0.25s linear"
        }).delay(50).queue(function(next){
            $(dom).css("top", "0px");
            next();
        }).delay(300).queue(function(next){
            $(dom).css({
                "transition-duration": "0.12s",
                "-moz-transition-duration": "0.12",
                "-webkit-transition-duration": "0.12s"
            });
            $(dom).css("top", "-18px");
            next();
        }).delay(135).queue(function(next){
            $(dom).css("top", "0px");
            next();
        });
    };
    
    skin.map.rotateAnimation = function(dom, duration){
        $(dom).css({
            "transition": "transform "+duration+"s linear",
            "-moz-transition": "-moz-transform "+duration+"s linear",
            "-webkit-transition": "-webkit-transform "+duration+"s linear"
        });
    };
    
    skin.map.doRotation = function(selector, degree){
        $(selector).css({
            "transform": "rotate("+degree+"deg)",
            "-webkit-transform": "rotate("+degree+"deg)",
            "-moz-transform": "rotate("+degree+"deg)"
        });
    };
    
    skin.map.floor = function(id){
        this.id = id;
        this.properties = {};
        this.layers = [];
    };
    
    skin.map.layer = function(level, imageMap){
        this.level = level;
        this.imageMap = imageMap;
    };
    
    skin.map.property = function(weight, action){
        this.weight = (weight)?weight:0;
        this.action = (action)?action:"remove";
        this.cleared = true;
        if(action == "fix" || action == "hide") this.container = {};
        else this.container = [];
    };
    
    skin.map.label = function(options){
        var span, div;
        this.setValues(options);
        span = this.span_ = document.createElement("span");
        span.className = "skin-label";
        span.style.cssText = "display: block; position: relative; left: -50%; white-space: nowrap;";

        div = this.div_ = document.createElement("div");
        div.appendChild(span);
        div.style.cssText = "position: absolute;";
        
        if(this.get("degree")) skin.map.doRotation(span, this.get("degree"));        
        if(!skin.isSet(this.get("zIndex"))) this.set("zIndex", "auto");
        if(this.get("css")) $(span).css(this.get("css"));
        if(this.get("rotateAnimTime")) skin.map.rotateAnimation(span, this.get("rotateAnimTime"));
        
        this.setVisible = function(visible){
            this.set("visible", visible);
        };
        
        this.getVisible = function(){
            return this.get("visible");
        };
        
        this.getPosition = function(){
            return this.get("position");
        };
    };

    skin.map.label.prototype = new google.maps.OverlayView;

    skin.map.label.prototype.onAdd = function(){
        var pane = this.getPanes().overlayMouseTarget, label = this;
        pane.appendChild(this.div_);
        this.listeners_ = [
            google.maps.event.addListener(this, "position_changed", function(){ label.draw(); }),
            google.maps.event.addListener(this, "visible_changed", function(){ label.draw(); }),
            google.maps.event.addListener(this, "clickable_changed", function(){ label.draw(); }),
            google.maps.event.addListener(this, "text_changed", function(){ label.draw(); }),
            google.maps.event.addListener(this, "zindex_changed", function(){ label.draw(); }),
            google.maps.event.addDomListener(this.span_, "click", function(){
                if(label.get("clickable")){
                    google.maps.event.trigger(label, "click");
                }
            })
        ];  
    };

    skin.map.label.prototype.onRemove = function(){
        this.div_.parentNode.removeChild(this.div_);
        for (var i=0, I=this.listeners_.length; i<I; ++i){
            google.maps.event.removeListener(this.listeners_[i]);
        }
    };

    skin.map.label.prototype.draw = function(){
        var div = this.div_, visible = this.get("visible"), mapZoom = this.getMap().getZoom(), minZoom = this.get("minZoom");
        if(visible && minZoom) visible = (mapZoom>=minZoom)?true:false;
        if(visible){
            var span = this.span_, projection = this.getProjection(), position = projection.fromLatLngToDivPixel(this.get("position")), sizeEq = this.get("sizeEq");
            
            $(div).css({
                "display": "block",
                "left": position.x + "px",
                "top": position.y + "px",
                "z-index": this.get("zIndex")
            });
            
            $(span).html(this.get("text"));
            
            if(skin.isFunction(sizeEq)){
                var fontSize = sizeEq(mapZoom);
                $(span).css({"font-size": fontSize});
            }
            
            $(span).css({
                "cursor": this.get("clickable")?"pointer":"default",
                "top": "-"+Math.round($(span).height()/2)+"px"    
            });
        }
        else{
            $(div).css({"display": "none"});
        }
        
    };

    skin.map.marker = function(options){
        var marker = this, imgHeight, image, span, cross, div;
        this.setValues(options);
               
        image = this.img_ = document.createElement("img");
        image.src = this.get("icon");
        
        image.style.cssText = "display: block; position: relative; visibility: hidden; top: -1000px;";
        
        span = this.span_ = document.createElement("span");
        span.className = "skin-marker";
        span.style.cssText = "display: block; position: relative; left: -50%; top: -100%;";
        span.appendChild(image);
        
        div = this.div_ = document.createElement("div");
        div.appendChild(span);
        div.style.cssText = "position: absolute;";
        
        if(this.get("title")) image.title = image.alt = this.get("title");
        if(this.get("degree")) skin.map.doRotation(span, this.get("degree"));
        if(this.get("dragCrossIcon")){
            cross = this.cross_ = document.createElement("img");
            cross.src = this.get("dragCrossIcon");
            cross.style.cssText = "display: block; position: absolute; visibility: hidden;";
            span.appendChild(cross);
        }
        if(!skin.isSet(this.get("zIndex"))) this.set("zIndex", "auto");
        if(this.get("css")) $(image).css(this.get("css"));
        if(this.get("rotateAnimTime")) skin.map.rotateAnimation(span, this.get("rotateAnimTime"));
        
        var setHeight = function(height){
            $(span).css({
                "top": "-"+height+"px",
                "height": (2*height)+"px"
            });
        };
        
        if(image.height){
            imgHeight = image.height;
            setHeight(imgHeight);
        }
        
        $(image).load(function(){
            if(!imgHeight){
                imgHeight = this.height;
                setHeight(imgHeight);
            }
            
            if(cross){
                var setCrossPosition = function(){
                    $(cross).css({
                        "top": (imgHeight-3-cross.height/2)+"px",
                        "left": (image.width/2 - cross.width/2)+"px",
                        "display": "none",
                        "visibility": "visible"
                    });
                };
                
                if(cross.height){
                    setCrossPosition();
                }
                else{
                    $(cross).load(function(){
                        setCrossPosition();
                    });
                }
            }
            if(marker.get("animation")) skin.map.dropAnimation(this, $(marker.getMap().getDiv()).height());
            else $(this).css("top", "0px");
            $(this).css("visibility", "visible");
        });
        
        this.setVisible = function(visible){
            if(this.getVisible() != visible){
                if(visible && this.get("animation")){
                    skin.map.dropAnimation(image, $(marker.get("map").getDiv()).height());
                }
                this.set("visible", visible);
            }
        };
        
        this.getVisible = function(){
            return this.get("visible");
        };
        
        this.getPosition = function(){
            return this.get("position");
        };
        
        this.setPosition = function(latlng){
            this.set("position", latlng);
        };
        
        this.setLocation = function(location){
            this.set("location", location);
        };
        
        this.getLocation = function(){
            return this.get("location");
        };
        
        this.getDraggable = function(){
            return this.get("draggable");
        };
        
        this.setDraggable = function(draggable){
            this.set("draggable", draggable);
        };
    };

    skin.map.marker.prototype = new google.maps.OverlayView;

    skin.map.marker.prototype.onAdd = function(){
        var pane = this.getPanes().overlayMouseTarget, marker = this, dragging, dragEnd;
        pane.appendChild(this.div_);
        this.listeners_ = [
            google.maps.event.addListener(this, "position_changed", function(){ marker.draw(); }),
            google.maps.event.addListener(this, "visible_changed", function(){ marker.draw(); }),
            google.maps.event.addListener(this, "clickable_changed", function(){ marker.draw(); }),
            google.maps.event.addListener(this, "zindex_changed", function(){ marker.draw(); }),
            google.maps.event.addDomListener(this.img_, "click", function(){
                if(marker.get("clickable")){
                    google.maps.event.trigger(marker, "click");
                }
            }),
            google.maps.event.addDomListener(this.img_, "mousedown", function(e){
                if(marker.get("draggable")){
                    if(!dragging){
                         var map = marker.getMap(), container = map.getDiv(), x = marker.div_.offsetLeft - e.pageX, y = marker.div_.offsetTop - e.pageY, moving = false;
                        
                        map.setOptions({draggable: false});
	                    dragging = google.maps.event.addDomListener(container, "mousemove", function(e2){
	                        if(!moving){
	                            $(marker.img_).css("top", "-12px");
	                            if(marker.cross_){
	                                $(marker.cross_).css("display", "block");
	                            }
	                            moving = true;
	                        }
	                        $(marker.div_).css("left", (x + e2.pageX)+"px");
	                        $(marker.div_).css("top", (y + e2.pageY)+"px");
	                        
	                    });
	                    
	                    dragEnd = google.maps.event.addDomListener(container, "mouseup", function(){
	                        var projection = marker.getProjection();
	                        google.maps.event.removeListener(dragging);
	                        google.maps.event.removeListener(dragEnd);
	                        dragging = dragEnd = null;
	                        $(marker.img_).css("top", "0px");
	                        if(marker.cross_){
	                            $(marker.cross_).css("display", "none");
	                        }
	                        marker.setPosition(projection.fromDivPixelToLatLng(new google.maps.Point(marker.div_.offsetLeft, marker.div_.offsetTop)));
	                        marker.getMap().setOptions({draggable: true});
                            google.maps.event.trigger(marker, "dragend");
	                    });
	                }
	                
	                google.maps.event.trigger(marker, "dragstart");
	            }
            })
        ];  
    };

    skin.map.marker.prototype.onRemove = function(){
        this.div_.parentNode.removeChild(this.div_);
        for (var i=0, I=this.listeners_.length; i<I; ++i){
            google.maps.event.removeListener(this.listeners_[i]);
        }
    };

    skin.map.marker.prototype.draw = function(){
        var div = this.div_, visible = this.get("visible"), mapZoom = this.getMap().getZoom(), minZoom = this.get("minZoom");
        if(visible && minZoom) visible = (mapZoom>=minZoom)?true:false;
        if(visible){
            var image = this.img_, projection = this.getProjection(), position = projection.fromLatLngToDivPixel(this.get("position"));
            $(image).css({
                "cursor": this.get("clickable")?"pointer":"default"
            });
            
            $(div).css({
                "display": "block",
                "left": position.x + "px",
                "top": position.y + "px",
                "z-index": this.get("zIndex")
            });

        }
        else{
            $(div).css({"display": "none"});
        }

    };


    skin.map.prototype = {
        zoomIn: function(){
            this.googleMap.setZoom(this.googleMap.getZoom()+1);
        
        },
        
        zoomOut: function(){
            this.googleMap.setZoom(this.googleMap.getZoom()-1);
        },
        
        viewCenter: function(){
            this.googleMap.setCenter(new google.maps.LatLng(this.center[0], this.center[1]));
            this.googleMap.setZoom(this.getOption("initZoom"));
        },
        
        registerFloor: function(name, id, setting){
            if(!setting.path) skin.alertError("No path");
            
            if(!skin.error){
                if(!skin.isSet(this.floors[name])){
                    this.floors[name] = new skin.map.floor(id);
                }
                var targetFloor = this.floors[name], map = this.googleMap, bounds;
                setting.path += (setting.path[setting.path.length-1] != "/")?"/":"";
            
                if(!skin.isSet(setting.level)) setting.level = targetFloor.layers.length;
    
                
                
                if(setting.swBound && setting.neBound){
                    bounds = new google.maps.LatLngBounds(
                        new google.maps.LatLng(setting.swBound[0], setting.swBound[1]),
                        new google.maps.LatLng(setting.neBound[0], setting.neBound[1])
                    );
                    var getTileBounds = function(tile, zoom, projection){
	                    var numTiles = 1<<zoom, tileSWCoord = projection.fromPointToLatLng( new google.maps.Point(tile.x*256/numTiles, (tile.y+1)*256/numTiles)), tileNECoord = projection.fromPointToLatLng( new google.maps.Point((tile.x+1)*256/numTiles, tile.y*256/numTiles));
	                    return new google.maps.LatLngBounds(tileSWCoord, tileNECoord);
                    };
                }
                
                var createBuildingLayer = function(){
		            return {
		                getTileUrl: function(tile, zoom){
			                var ymax = 1 << zoom, y = ymax - tile.y -1, projection = map.getProjection();
			                if(bounds || bounds.intersects(getTileBounds(tile, zoom, projection))){
				                return setting.path+zoom+"/"+tile.x+"/"+y+".png";
			                }
			                else{
				                return false;
			                }
		                },
		                tileSize: new google.maps.Size(256, 256)
		            };
	            };
                
                targetFloor.layers.push(new skin.map.layer(setting.level, new google.maps.ImageMapType(createBuildingLayer())));
                
            }

        },

        putFloor: function(name){
            if(this.floors[name]){
                this.clearLayers();
                this.currentFloor = name;
                var targetFloor = this.floors[name].layers, map = this.googleMap;
                $.each(targetFloor, function(ind, ele){
                    map.overlayMapTypes.insertAt(ele.level, ele.imageMap);
                });
            }
        },
        
        clearLayers: function(){
            this.googleMap.overlayMapTypes.clear();
        },
        
        registerProperty: function(floorName, type, weight, action){
            if(skin.isSet(this.floors[floorName])){
                var targetFloor = this.floors[floorName];
                if(!skin.isSet(targetFloor.properties[type])) targetFloor.properties[type] = new skin.map.property(weight, action);
                else skin.alertError("Duplicate overlay type");
            }
            else skin.alertError("Floor doesn't exist");
        },
        
        clearProperties: function(weight){
            if(skin.isSet(this.currentFloor)){
                var targetProperties = this.floors[this.currentFloor].properties;
                if(!skin.isSet(weight)) weight = false;
                $.each(targetProperties, function(ind, ele){
                    if(weight === false || weight >= ele.weight){
                        if(ele.action == "remove"){
                            while(ele.container.length) ele.container.pop().setMap(null);
                        }
                        else if(ele.action == "hide" || ele.action == "fix"){
                            $.each(ele.container, function(id, overlays){
                                $.each(overlays, function(overlayInd, overlay){
                                    overlay.setVisible(false);
                                });
                            });
                            
                            if(ele.action == "fix") ele.cleared = true;
                        }

                    }
                
                });
               
            }
        },
        
        clearProperty: function(type){
            if(skin.isSet(type) && skin.isSet(this.currentFloor)){
                var property = this.floors[this.currentFloor].properties[type], action = property.action;
                if(action == "remove"){
                    while(property.container.length) property.container.pop().setMap(null);
                }
                else if(action == "hide" || action == "fix"){
                    $.each(property.container, function(id, overlays){
                        $.each(overlays, function(overlayInd, overlay){
                            overlay.setVisible(false);
                        });
                    });
                    if(action == "fix") property.cleared = true;
                }
            }
        },
        
        showProperties: function(weight){
            if(skin.isSet(this.currentFloor)){
                var targetProperties = this.floors[this.currentFloor].properties;
                if(!skin.isSet(weight)) weight = false;
                $.each(targetProperties, function(ind, ele){
                    if(weight === false || ele.weight > weight){
                        if(ele.action == "fix" && ele.cleared){
                            $.each(ele.container, function(id, overlays){
                                $.each(overlays, function(overlayInd, overlay){
                                    overlay.setVisible(true);
                                });

                            });
                            ele.cleared = false;
                        }
                    }
                
                });
                
                
            }
        },
        
        addItem: function(type, overlay, id, floorName){
            var floor = (skin.isSet(floorName))?floorName:this.currentFloor, property = this.floors[floor].properties[type];
            if(skin.isSet(id)){
                if(!this.isSetContainer(type, id, floor)) property.container[id] = [];
                property.container[id].push(overlay);
            }
            else{
                property.container.push(overlay);
            }

        },
        
        getContainer: function(type, id, floorName){
            var floor = skin.isSet(floorName)?floorName:this.currentFloor, property = this.floors[floor].properties[type];
            if(property.action == "remove"){
                return property.container;
            }
            else if(skin.isSet(id) && (property.action == "fix" || property.action == "hide")){
                if(!this.isSetContainer(type, id, floor)) property.container[id] = [];
                return property.container[id];
            }

        },
        
        isSetContainer: function(type, id, floorName){
            var floor = skin.isSet(floorName)?floorName:this.currentFloor, property = this.floors[floor].properties[type];
            if(skin.isSet(id)){
                return (skin.isSet(property.container[id]));
            
            }
            else{
                return property.container.length;
            }
        },
        
        getWeight: function(type, floorName){
            var floor = skin.isSet(floorName)?floorName:this.currentFloor;
            return this.floors[floor].properties[type].weight;
        }
       

    };
    
    return skin;


})(jQuery, google, skin || {});
