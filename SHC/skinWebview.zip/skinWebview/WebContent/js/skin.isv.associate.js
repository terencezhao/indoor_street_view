var panorama;
var polyLine;
var markers = [];
var isvData = {};

function initialize(callback) // USING CALLBACK FUNCTION LIKE A BOSS!
{
	$.get(" http://localhost:8080/SKIN20/Web/isv/getPanos?sid=1570", {}, function(panoData){  		
	    if(panoData)
	    {
			for(index in panoData)
			{	
				var obj = panoData[index];
				var entry = obj[0].id;	      	        
				isvData[entry] =
				{
					pano: obj[0].id,
					description: obj[0].desc,
					latLng: new google.maps.LatLng(obj[1].lat, obj[1].lng),
					links:
					[
						{pano: obj[0].isvLink1, heading: obj[0].heading1},
						{pano: obj[0].isvLink2, heading: obj[0].heading2},
						{pano: obj[0].isvLink3, heading: obj[0].heading3},
						{pano: obj[0].isvLink4, heading: obj[0].heading4},
						{pano: obj[0].isvLink5, heading: obj[0].heading5}
					]
				};
	  	  	};
	  	  	callback();
	  	}
	});
}
initialize(function(){
	control.getLocations(1);
	setUpMarkers();
	setUpPolyLine();
	setUpStreetView();
	$('#street-view').slideUp();
	$("#select-floor").change(function(){
		var floor = $("#select-floor").val();
		alert(floor);
		control.changeFloor(floor);
		//control.getLocations(floor);
	});
});

function setUpMarkers()
{
 	for (var key in isvData)
 	{
 		if (isvData.hasOwnProperty(key))
 		{
 			var title = isvData[key].description;
 			var position = isvData[key].latLng;
 			var icon = "drag_cross.png";
 			var marker = new google.maps.Marker({
 				title: key,
 				icon: control.get("imgDir")+icon,
 				position: position,
 				map: control.map.googleMap,
 				visible: true
 			});
 			markers.push(marker);
 			clickListener(marker, key);
 		}
 	}
}

function clickListener(marker, key)
{
	google.maps.event.addListener(marker, 'click', function(){
		panorama.setPano(key);			
		setCurrentMarker(key);
		$('#street-view').slideDown();
	});	
}

function setCurrentMarker(key)
{
	for	(index in markers)
	{
		if(markers[index].title != key)
		{
			//markers[index].setAnimation(null);
			markers[index].setIcon(control.get("imgDir")+"me.png");
		}
		else
		{	
			//markers[index].setAnimation(google.maps.Animation.BOUNCE);
			markers[index].setIcon(control.get("imgDir")+"me_green.png");
		}
	}
}

function setUpPolyLine()
{
	for (var key in isvData)
	{
		if(isvData.hasOwnProperty(key))
		{
			var current = isvData[key];
			var start = current.latLng;
			for (index in current.links)
			{
				var linkID = current.links[index].pano;
				if(typeof linkID != 'undefined')
				{
					var end = isvData[linkID].latLng;
					var path = new Array();
					path.push(start, end);
					control.addPolyLine("royalblue", 0.25, 10, path);
				}
			}
		}
	}
}

// STREET VIEW STUFF
function setUpStreetView()
{
	var panoOptions =
	{
		visible: true,
		disableDoubleClickZoom: false,
		zoomControl: true,
		panControl: false,
		panoProvider: getAutoPanorama,
		pov: {
			heading: 0,
			pitch: 0,
			zoom: 0
		}
	};		
	panorama = new google.maps.StreetViewPanorama(document.getElementById("street-view"), panoOptions);
	//panorama.setPano("woodfield1");
}


function getCustomPanoramaTileUrl(pano,zoom,tileX,tileY) 
{
	var url = 'http://skin-dev.searshc.com/Skin20ISV/woodfield/'+pano+'-tiles'+'/'+pano+'_'+zoom+'_'+tileX+'_'+tileY+'.jpg';
	var test = control.get("imgDir")+pano+".jpg";
	return test;
}


function getAutoPanorama(pano)
{
//WEBSERVICE: Push a link for panoA with heading, description and pano
	var customPano = isvData[pano];
 	setCurrentMarker(pano);
	var links = getCustomLinks(pano);
	return {
		location:
		{
			pano: customPano.pano.toString(),//pano,
			description: customPano.description.toString(),//pano,//customPano.description,
			latLng: customPano.latLng,//customPano.latLng
		},
		links: links,//customPano.links,
		copyright: '(c) 2012 SHC',//customPano.copyright,
		tiles:
		{
			tileSize: new google.maps.Size(4096, 2048),//customPano.tileSize,
			worldSize: new google.maps.Size(4096, 2048),//customPano.worldSize,
			centerHeading: 0,//customPano.centerHeading,
			getTileUrl: getCustomPanoramaTileUrl
		}
	};
}

function getCustomLinks(pano)
{
 	var links = [];
 	var customPano = isvData[pano];
 	for (index in customPano.links)
	{
		var linkID = customPano.links[index].pano;
		if(typeof linkID != 'undefined')
		{
			links.push({
				heading: customPano.links[index].heading,
				description: isvData[linkID].description.toString(),
				pano: isvData[linkID].pano.toString()
			});
		}
	}	
 	return links;
}
// END OF STREET VIEW STUFF
