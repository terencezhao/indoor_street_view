package main;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Init {
	String storeNumber = "";
    String platform = "";
    String js = "";
    
   // String baseUrl = "http://skin.searshc.com/web/";
    String baseUrl = "http://localhost:8080/skinWebview/";
    
    public void setStoreNumber( String value ){
     	if(validator("^[0-9]+$", value)){
    		storeNumber = value;
    	}
    }

    public void setPlatform( String value ){
    	if(validator("^[a-z0-9]+$", value)){
    		platform = value;
    	}
    }
    
    public void setJs( String value ){
   		js = value;
    }
    
    public String getStoreNumber(){
    	return storeNumber;
    }

    public String getPlatform() {
    	return platform;
    }
    
    public String getJs() {
    	return js;
    }
    
    public String getBaseUrl() {
    	return baseUrl;
    }
    
    private boolean validator(String pattern, String str){
    	Pattern reg = Pattern.compile(pattern);
    	Matcher m = reg.matcher(str);
    	return m.matches();
    	
    }
    

}


