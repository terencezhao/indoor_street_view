package ws;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class getImportantPoi extends HttpServlet {
	WebService ws = new WebService();
	private String wsUrl = ws.url+"store/poilocs?imp=1&store=";
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		
		PrintWriter out;
		res.setContentType("text/plain");
	    out = res.getWriter();
		
		try{
		    String storeNumber = req.getParameter("storeNumber");
		    String response = ws.webServiceCall(wsUrl+storeNumber);
		    out.println(response);
		} 
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	  

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doGet(req, res);
	}
}