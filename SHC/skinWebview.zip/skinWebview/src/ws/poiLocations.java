package ws;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;


public class poiLocations extends HttpServlet {
	WebService ws = new WebService();
	private String wsUrl = ws.url+"store/poilocs?store=%s&floor=%s&poiId=%s";
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		
		PrintWriter out;
		res.setContentType("text/plain");
	    out = res.getWriter();
		
		try{
		    String storeNumber=req.getParameter("storeNumber");
		    String floorName=req.getParameter("floorName");
		    String poiId=req.getParameter("poiId");
		    String requestUrl = String.format(wsUrl, storeNumber, floorName, poiId);
		    String response = ws.webServiceCall(requestUrl);
		    out.println(response);
		} 
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	  

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doGet(req, res);
	}
	
	public String webServiceCall(String url){
		
		//Creating the HTTP GET request 
		HttpClient httpclient = new DefaultHttpClient();
		HttpGet request = new HttpGet(url);

		//request.addHeader("accept", "application/json");
		

		String response="";
		
		ResponseHandler<String> handler = new BasicResponseHandler();
		try {  
			response = httpclient.execute(request, handler);  
        } catch (ClientProtocolException e) {  
            e.printStackTrace();  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
        httpclient.getConnectionManager().shutdown();
        
        
        return response;
		
		
	}

}